# operator.tools
Utilities for working with R's operators
