export default global.Shiny;
