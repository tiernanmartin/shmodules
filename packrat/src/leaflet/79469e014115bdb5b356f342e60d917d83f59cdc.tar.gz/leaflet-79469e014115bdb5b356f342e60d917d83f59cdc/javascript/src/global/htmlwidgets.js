export default global.HTMLWidgets;
